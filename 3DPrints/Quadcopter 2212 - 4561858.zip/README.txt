Quadcopter 2212 by TB_3D on Thingiverse: https://www.thingiverse.com/thing:4561858

Summary:
watch my youtube channel to make it easier :-video Test : https://youtu.be/KzEmVfZ1b9oIf it is useful, support me by Subscribing to my Youtube Channel:https://www.youtube.com/c/TB3Dprinting?sub_confirmation=1-Instagram : https://www.instagram.com/tblack3dprinter/-Cults3d : https://cults3d.com/en/users/TB3D/creations-Myminifactory : https://www.myminifactory.com/users/TB3D